<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/test_project/Blog/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>