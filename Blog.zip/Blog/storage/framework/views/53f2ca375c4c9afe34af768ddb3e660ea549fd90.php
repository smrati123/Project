<a href="<?php echo e(url('add')); ?>" style="float: right;margin-right: 50px;" class="btn btn-primary" >Add User</a>

<h1>Member List</h1>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.w-5{
  display:none;
}
</style>
<table border="1">
    <tr>
        <td>ID</td>
        <td>Name</td>
        <td>Email</td>
        <td>Address</td>
        <td>Operations</td>
    </tr>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($member['id']); ?></td>
        <td><?php echo e($member['name']); ?></td>
        <td><?php echo e($member['email']); ?></td>
        <td><?php echo e($member['address']); ?></td>
        <td><a href=<?php echo e("edit/" .$member['id']); ?>>Edit</a>
        <a href=<?php echo e("delete/" .$member['id']); ?>>Delete</a></td>
    </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<div>
  <?php echo e($members->links()); ?>

</div><?php /**PATH /opt/lampp/htdocs/test_project/Blog/resources/views/list.blade.php ENDPATH**/ ?>