<p>Click on the "Choose File" button to upload a file:</p>

<form action="upload" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
  <input type="file" name="filename"><br><br>
  <button type="submit">Upload File </button>
</form><?php /**PATH /opt/lampp/htdocs/test_project/Blog/resources/views/upload.blade.php ENDPATH**/ ?>