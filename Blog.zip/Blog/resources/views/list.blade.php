<a href="{{ url('add') }}" style="float: right;margin-right: 50px;" class="btn btn-primary" >Add User</a>

<h1>Member List</h1>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.w-5{
  display:none;
}
</style>
<table border="1">
    <tr>
        <td>ID</td>
        <td>Name</td>
        <td>Email</td>
        <td>Address</td>
        <td>Operations</td>
    </tr>
    @foreach($members as $member)
    <tr>
        <td>{{$member['id']}}</td>
        <td>{{$member['name']}}</td>
        <td>{{$member['email']}}</td>
        <td>{{$member['address']}}</td>
        <td><a href={{"edit/" .$member['id']}}>Edit</a>
        <a href={{"delete/" .$member['id']}}>Delete</a></td>
    </tr> 
    @endforeach
</table>

<div>
  {{$members->links()}}
</div>