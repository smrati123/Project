<p>Click on the "Choose File" button to upload a file:</p>

<form action="upload" method="POST" enctype="multipart/form-data">
@csrf
  <input type="file" name="filename"><br><br>
  <button type="submit">Upload File </button>
</form>