<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;



class UserController extends Controller
{
    public function store(Request $req)
    {
        $validateData=$req->validate([
            "user_name"=>"required",
            "email"=>"required|string|email|max:255|unique:users",
            "phone_no"=>"required|max:13|unique:users|regex:/^(\+\d{1,3}[- ]?)?\d{10}$/",
            "password"=>"required|string|min:6|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/",
            "street_address"=>"required",
            "city"=>"required",
            "state"=>"required",
            "country"=>"required",
            "zipcode"=>"required|max:6"
            
        ]);
        $users=new User;
        $users->user_name=$req->user_name;
        $users->email=$req->email;
        $users->phone_no=$req->phone_no;
        $password = $req->password;
        $hashPassword = password_hash($password, PASSWORD_DEFAULT);
        $users->password= $hashPassword;
        $users->street_address=$req->street_address;
        $users->city=$req->city;
        $users->state=$req->state;
        $users->country=$req->country;
        $users->zipcode=$req->zipcode;
        $users->created_at=gmdate('Y-m-d h:i:s');
        $users->save();
        return response()->json(['message'=>'user add successully'],200);
    }
    
     function userData()
    {
        return User::all();
    }  
    function update(Request $req)
    {
       
        $id = $req->user_id;
        $user_name = $req->user_name;
        $email = $req->email;
        $phone_no = $req->phone_no;
        $street_address = $req->street_address;
        $city = $req->city;
        $state = $req->state;
        $country = $req->country;
        $zipcode = $req->zipcode;
        
        $update = User::updateUser($id, $user_name, $email, $phone_no, $street_address, $city, $state, $country, $zipcode);
        if($update)
        return response()->json(['message'=>'user update successully'],200);
        else
        return response()->json(['message'=>'something went wrong'],201);

    }
    function delete($id)
    {
        $users=User::find($id);
        $users->delete();
        return response()->json(['message'=>'user delete successully'],200);
        
    }

    function search(Request $req)
    {
        $user_name=$req->user_name;
        $email=$req->email;

        $result = User::where('user_name', 'LIKE', '%'. $user_name. '%')
                ->orWhere('email', 'LIKE', '%'. $email. '%')
                ->get();
        if(count($result)){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['Result' => 'No Data not found'], 404);
      }
    }
}
